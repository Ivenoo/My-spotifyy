Saiyan-Sans Font - PC Version

Freeware Font by Ben Palmer, www.tboyonline.com
==============================================================

Contents:
Saiyan-Sans.ttf
Saiyan-Sans Left Oblique.ttf
Saiyan-Sans Right Oblique.ttf
dbz.png - A visual guide for DBZ-like implementation

Thanks for downloading this font. I built it after not being
able to find a Dragonball Z font anywhere on the web, so from
the logo I just kinda tried to follow Akira Toriyama's style
for the other letters.


Implementation
--------------------------------------------------------------

If you are using it for doing DBZ like headers, these are the
rules I have figured out

<----------- O ------------>

Use the Left Oblique for the left hand side of the Dragonball
(letter o) and Right Oblique for the right hand side.


==============================================================
If you distribute this please just like to my website, othewise
have fun and I hope you like.